package org.example.controller;

import lombok.extern.slf4j.Slf4j;
import org.example.model.GitHubStats;
import org.example.service.GitHubStatsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/v1/github-stats")
@Slf4j
public class GitHubStatsController {
    private final GitHubStatsService githubStatsService;

    @Autowired
    public GitHubStatsController(GitHubStatsService githubStatsService) {
        this.githubStatsService = githubStatsService;
    }

    @GetMapping("/top-org-repos")
    public ResponseEntity<List<GitHubStats>> getTopOrgRepos(
            @RequestParam String org,
            @RequestParam(defaultValue = "5") int limit) {
        try {
            log.info("Fetching top {} repos for organization: {}", limit, org);
            List<GitHubStats> stats = githubStatsService.getTopOrgRepos(org, limit);

            if (stats.isEmpty()) {
                log.warn("No repositories found for organization: {}", org);
                return ResponseEntity.noContent().build();
            }

            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            log.error("Error fetching repos for org {}: {}", org, e.getMessage());
            return ResponseEntity.internalServerError().build();
        }
    }
}