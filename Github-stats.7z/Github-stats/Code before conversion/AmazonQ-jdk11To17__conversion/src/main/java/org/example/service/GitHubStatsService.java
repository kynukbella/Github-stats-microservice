package org.example.service;

import lombok.extern.slf4j.Slf4j;
import org.example.model.ContributorStats;
import org.example.model.GitHubStats;
import org.example.model.Breakdown;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class GitHubStatsService {
    private final GitHubApiClient githubApiClient;

    @Autowired
    public GitHubStatsService(GitHubApiClient githubApiClient) {
        this.githubApiClient = githubApiClient;
    }

    public List<GitHubStats> getTopOrgRepos(String org, int limit) {
        if (StringUtils.isEmpty(org)) {
            log.error("Organization name cannot be empty");
            throw new IllegalArgumentException("Organization name is required");
        }

        if (limit <= 0) {
            log.error("Limit must be greater than 0");
            throw new IllegalArgumentException("Invalid limit value");
        }

        try {
            log.debug("Fetching top {} repos for org: {}", limit, org);
            List<GitHubStats> stats = githubApiClient.fetchTopOrgRepos(org);

            // Apply limit if needed
            if (stats.size() > limit) {
                stats = stats.subList(0, limit);
            }

            log.info("Successfully fetched {} repos for org: {}", stats.size(), org);
            return stats;
        } catch (Exception e) {
            log.error("Failed to fetch repos for org {}: {}", org, e.getMessage());
            throw new RuntimeException("Failed to fetch repository data", e);
        }
    }
}